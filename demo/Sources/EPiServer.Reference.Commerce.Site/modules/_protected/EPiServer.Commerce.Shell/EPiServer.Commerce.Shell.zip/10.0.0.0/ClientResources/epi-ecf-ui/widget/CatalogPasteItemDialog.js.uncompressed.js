﻿define("epi-ecf-ui/widget/CatalogPasteItemDialog", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-construct",

// dijit
    "dijit/_Widget",

// epi
    "epi",
    "epi/shell/widget/_ActionProviderWidget",
    "epi/shell/widget/dialog/_DialogContentMixin",
    "epi/i18n!epi/cms/nls/commerce.widget.pasteitemdialog"

], function (
// dojo
    declare,
    lang,
    domConstruct,

// dijit
    _Widget,

// epi
    epi,
    _ActionProviderWidget,
    _DialogContentMixin,
    resources
){
    return declare([_Widget, _ActionProviderWidget, _DialogContentMixin], {

        hideMoveOption: false,
        
        hideLinkOption: false,

        title: resources.title,

        buildRendering: function () {
            this.inherited(arguments);

            domConstruct.create("span", { innerHTML: resources.message }, this.domNode);
        },

        getActions: function () {
            // summary:
            //      Overridden from _ActionProvider

            this._actions = [];
            
            this._actions.push({
                name: "duplicate",
                label: resources.duplicate,
                settings: { type: "button" },
                action: lang.hitch(this, function() {
                    this.executeDialog('duplicate');
                })
            });
            
            if (!this.hideLinkOption) {
                this._actions.push({
                    name: "link",
                    label: resources.link,
                    settings: { type: "button" },
                    action: lang.hitch(this, function() {
                        this.executeDialog('link');
                    })
                });
            }
            
            if (!this.hideMoveOption) {
                this._actions.push({
                    name: "move",
                    label: resources.move,
                    settings: { type: "button" },
                    action: lang.hitch(this, function() {
                        this.executeDialog('move');
                    })
                });
            }
            
            this._actions.push({
                name: "cancel",
                label: epi.resources.action.cancel,
                settings: { type: "button" },
                action: lang.hitch(this, function () {
                    this.cancelDialog();
                })
            });
            
            return this._actions;
        }
    });
});