//>>built
define("epi-ecf-ui/contentediting/editors/CheckBoxEditor",["dojo/_base/declare","epi/shell/widget/CheckBox"],function(_1,_2){return _1([_2],{focus:function(){this.checkbox.focus();}});});