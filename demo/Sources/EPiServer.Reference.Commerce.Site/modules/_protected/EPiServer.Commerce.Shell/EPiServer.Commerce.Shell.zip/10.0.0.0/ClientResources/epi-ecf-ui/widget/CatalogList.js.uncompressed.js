﻿define("epi-ecf-ui/widget/CatalogList", [
// Dojo
    "dojo",
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/html",
    "dojo/topic",
    "dojo/dom-class",
    "dojo/dom-style",

// EPi Shell
    "epi",
    "epi/dependency",
    "epi/shell/widget/_FocusableMixin",

// EPi CMS
    "epi-cms/dgrid/formatters",
    "epi-cms/widget/_ConfigurableContentListBase",
    "epi-cms/contentediting/ContentActionSupport",
//commerce
   "./viewmodel/CatalogListViewModel",

// Resources
    "epi/i18n!epi/cms/nls/commerce.widget.cataloglist"
], function (
// Dojo
    dojo,
    array,
    declare,
    lang,
    html,
    topic,
    domClass,
    domStyle,

// EPi Shell
    epi,
    dependency,
    _FocusableMixin,

// EPi CMS
    formatters,
    _ConfigurableContentListBase,
    ContentActionSupport,
//commerce
    CatalogListViewModel,
// Resources
    res) {

    return declare([_ConfigurableContentListBase, _FocusableMixin], {
        // summary:
        //    Lists the content of the catalog root.
        // description:
        //    This is the widget that lists the content of the catalog root.
        // tags:
        //    public

        // contextChangeEvent: [public] String
        //      Setup so that the context change events are not configured in the base class.
        contextChangeEvent: "",

        startup: function () {
            // summary:
            //      Adds the breadcrumb widget to the top of the list widget.
            // tags:
            //      protected
            this.inherited(arguments);

            this.own(
                topic.subscribe("relationChanged", lang.hitch(this, function () {
                    this.grid.refresh();
                })),
                topic.subscribe("catalogContentDeleted", lang.hitch(this, function (deletedItems) {
                    this.grid.refresh();
                }))
            );
        },

        getListSettings: function(){
            var baseSettings = this.inherited(arguments);
            return lang.mixin(baseSettings, {
                className: "epi-plain-grid epi-plain-grid--small-header-font"
            });
        },

        fetchData: function (context) {
            // summary:
            //		Fetches data by setting a query on the grid. A getrelations query will be performed on the store.
            // tags:
            //		protected

            var queryOptions = { ignore: ["query"], parentId: context.id, sort: [{ attribute: "name" }] };

            var queryParameters = {
                referenceId: context.id,
                query: "getchildren",
                includeProperties: true,
                allLanguages: true
            };

            this.grid.set("query", queryParameters, queryOptions);
        },

        createModel: function () {
            // summary:
            //      Overriden to contruct the default model for the catalog list
            return new CatalogListViewModel();
        },

        getColumnSettings: function () {
            // summary:
            //		Returns an object with the settings for the columns of the grid
            // tags:
            //		private

            return {
                /* Name of column used in sorting - use typeSortIndex property, not typeIdentifier */
                typeSortIndex: {
                    renderHeaderCell: function (node) {
                        domClass.add(node, "epi-columnPadding--left");
                    },
                    get: function (object) {
                        return object.typeIdentifier;
                    },
                    formatter: formatters.contentIcon,
                    className: "epi-columnIcon16x16",
                    sortable: false,
                    renderCell: function (object, value, node, options) {
                        domClass.add(node, "epi-columnPadding--left");
                        node.innerHTML = formatters.contentIcon(value);
                    }
                },
                name: {
                    label: epi.resources.header.name,
                    className: "epi-columnWide"
                },
                language: {
                    get: function (object) {
                        return object.properties.defaultLanguage;
                    },
                    label: epi.resources.header.language,
                    sortable: false
                },
                currency: {
                    get: function (object) {
                        return object.properties.defaultCurrency;
                    },
                    label: epi.resources.header.currency,
                    sortable: false
                },
                baseWeight: {
                    get: function (object) {
                        return object.properties.weightBase;
                    },
                    label: res.baseweight,
                    sortable: false
                },
                baseLength: {
                    get: function (object) {
                        return object.properties.lengthBase;
                    },
                    label: res.baselength,
                    sortable: false
                },
                isPendingPublish: {
                    get: function (object) {
                        return object.status === ContentActionSupport.versionStatus.Published;
                    },
                    label: res.active,
                    formatter: formatters.friendlyBoolean,
                    className: "epi-columnNarrow"
                },
                startPublish: {
                    get: function (object) {
                        return object.properties.startPublish;
                    },
                    label: res.availablefrom,
                    formatter: this._localizedDateAndSecondaryText
                },
                stopPublish: {
                    get: function (object) {
                        return object.properties.stopPublish;
                    },
                    label: epi.resources.header.expires,
                    formatter: this._localizedDateAndSecondaryText
                },
                owner: {
                    get: function (object) {
                        return object.properties.owner;
                    },
                    label: epi.resources.header.owner,
                    formatter: formatters.secondaryText,
                    sortable: false
                }
            };
        },

        setupEvents: function () {
            this.inherited(arguments);
            for (var columnName in this.getColumnSettings()) {
                this.own(this.grid.on(".dgrid-cell.dgrid-column-" + columnName + ":click", lang.hitch(this, "_onChangeContext")));
            }
        },

        _localizedDateAndSecondaryText: function (value) {
            return formatters.secondaryText(formatters.localizedDate(value), true);
        }
    });
});
