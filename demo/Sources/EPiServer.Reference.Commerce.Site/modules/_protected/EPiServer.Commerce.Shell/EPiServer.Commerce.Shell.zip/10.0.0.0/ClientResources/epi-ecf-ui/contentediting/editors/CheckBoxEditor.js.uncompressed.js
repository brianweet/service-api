define("epi-ecf-ui/contentediting/editors/CheckBoxEditor", [
// dojo
    "dojo/_base/declare",

// epi
    "epi/shell/widget/CheckBox"
], function (
// dojo
    declare,

// epi
    CheckBox
) {
    return declare([CheckBox], {
        // module:
        //  epi-ecf-ui/contentediting/editors/CheckBoxEditor
        // summary:
        //    Updates the epi/shell/widget/CheckBox with focus support. TODO: Remove when bug CMS-4574 is fixed.
        // tags:
        //    public

        focus: function () {
            this.checkbox.focus();
        }
    });
});
