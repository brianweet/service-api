﻿define("epi-ecf-ui/contentediting/editors/InventoryCollectionReadOnlyEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    // epi commerce
    "./ReadOnlyCollectionEditor",
    "../viewmodel/InventoryCollectionReadOnlyEditorModel",

        // Resources
    "epi/i18n!epi/cms/nls/commerce.components.catalogs.commands"
],
function (
    //dojo
    declare,
    lang,

    // epi commerce
    ReadOnlyCollectionEditor,
    InventoryCollectionReadOnlyEditorModel,

    res
) {
    return declare([ReadOnlyCollectionEditor], {
        // module: 
        //      epi-ecf-ui/contentediting/editors/InventoryCollectionReadOnlyEditor
        // summary:
        //      Represents the Read-only editor widget for product's inventory list.

        iconClass: "epi-iconBoxes",

        modelType: InventoryCollectionReadOnlyEditorModel,
                
        changeToView: "inventoryview",
        
        buttonLabel: res.editinventories

    });
});