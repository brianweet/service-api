﻿define("epi-ecf-ui/command/PasteCatalogContent", [
// dojo
    "dojo/_base/declare",
    
// framework
    "epi/shell/TypeDescriptorManager",

// cms
    "epi-cms/command/PasteContent",

// epi-ecf-ui
    "../contentediting/ModelSupport"
],

function (
// dojo
    declare,
    
// framework
    TypeDescriptorManager,

// cms
    PasteContent,

// epi-ecf-ui
    ModelSupport
) {

    // module:
    //      epi-ecf-ui/command/PasteCatalogContent
    // summary:
    //      A command that pastes whats in the clip board onto the current selection.
    //      Inherits from the general content past command in cms, and changes behaviour when the command can be executed.
    // tags:
    //      public

    return declare([PasteContent], {

        typeDescriptorManager: TypeDescriptorManager,
        
        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected override

            var selectedData = this.get("selectionData");

            if (selectedData) {
                var isCopyToProduct = this.clipboard.isCopy() && this._typeIsAssignableFrom(selectedData.typeIdentifier, ModelSupport.contentTypeIdentifier.productContent);

                // check the type identifier is base on both node and product content type
                if (this._typeIsAssignableFrom(selectedData.typeIdentifier, ModelSupport.contentTypeIdentifier.nodeContentBase) || isCopyToProduct) {
                    this.inherited(arguments);
                    this.set("isAvailable", true);
                    return;
                }
            }
            this._hideCommand();
        },

        _typeIsAssignableFrom: function (/*string*/ type, /*string*/ baseTypeToSupport) {
            return this.typeDescriptorManager.isBaseTypeIdentifier(type, baseTypeToSupport);
        },

        _hideCommand: function() {
            this.set("isAvailable", false);
        }
    });

});