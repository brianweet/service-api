﻿define("epi-ecf-ui/contentediting/viewmodel/PricingOverviewEditorModel", [
    // dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/currency",
    "dojo/when",
    "dojo/Stateful",
    "dojo/Evented",
    "dojo/promise/all",
    // dojox
    "dojox/html/entities",
    // epi
    "epi/shell/_StatefulGetterSetterMixin",
    "epi/shell/command/DelegateCommand",
    "epi/dependency",
    "epi/datetime",
    "epi/string",
    //resources
    "epi/i18n!epi/cms/nls/commerce.widget.pricingoverview.grid",
    "epi/i18n!epi/cms/nls/commerce.widget.pricecollection.message"
],
function (
    //dojo
    array,
    declare,
    lang,
    currency,
    when,
    Stateful,
    Evented,
    all,
    // dojox
    htmlEntities,
    // epi
    _StatefulGetterSetterMixin,
    DelegateCommand,
    dependency,
    epiDate,
    epiString,
    //resources
    resources,
    res
) {
    return declare([Stateful, _StatefulGetterSetterMixin, Evented], {
        // module:
        //      epi-ecf-ui/contentediting/viewmodel/PricingOverviewEditorModel
        // summary:
        //      Represents the model for PricingOverviewEditor

        _storeKey: "epi.commerce.price",

        store: null,

        metadataManager: null,

        contentLink: null,

        marketId: null,

        priceCode: null,

        queryOptions: null,

        getChildrenQueryName: "getpricechildren",

        postscript: function () {
            this.inherited(arguments);

            this.storeRegistry = dependency.resolve("epi.storeregistry");
            this.store = this.store || this.storeRegistry.get(this._storeKey);

            this.metadataManager = this.metadataManager || dependency.resolve("epi.shell.MetadataManager");
        },

        _createQueryOptions: function () {
            // summary:
            //      Creates and returns query options, based on selected content link, market id and customer group (if any).
            // tags:
            //      private

            var query = { referenceId : this.get("contentLink"), query: this.getChildrenQueryName },
                ignoreOptions = ["query", "referenceId"];

            if (this.get("marketId")) {
                lang.mixin(query, { marketId: this.get("marketId") });
                if (query.marketId === "ALL") {
                    ignoreOptions.push("marketId");
                }
            }

            if (this.get("priceCode")) {
                lang.mixin(query, { priceCode: this.get("priceCode") });
                if (query.priceCode === "ALL"){
                    ignoreOptions.push("priceCode");
                }
            }

            return { query: query, options: { ignore: ignoreOptions } };
        },

        getCommands: function (model, category) {
            var commonSettings = {
                category: category,
                model: model,
                canExecute: true,
                isAvailable: true
            };

            return [
                new DelegateCommand(lang.mixin({
                    name: "duplicate",
                    label: resources.commands.duplicate,
                    iconClass: "epi-iconDuplicatePage",
                    delegate: lang.hitch(this, function (cmd) {
                        this.emit("duplicateCommandEvent");
                    })
                }, commonSettings)),
                new DelegateCommand(lang.mixin({
                    name: "remove",
                    label: resources.commands.remove,
                    iconClass: "epi-iconClose",
                    delegate: lang.hitch(this, function (cmd) {
                        this.emit("removeCommandEvent");
                    })
                }, commonSettings))
            ];
        },

        addItem: function(item) {
            return when(this.store.add(item), lang.hitch(this, function(data) {
                this.emit("itemAdded", { id: data.id });
            }));
        },

        removeItems: function (models) {

            var promises = [];

            for (var i = 0, j = models.length; i < j; i += 1) {
                promises.push(this.store.remove(models[i].id));
            }

            return all(promises).then(lang.hitch(this, function(removed) {
                this.emit("itemsRemoved", { removedItems: removed });
            }));
        },

        generateFormatters: function (columnDefinitions, editableColumns) {
            for(var definitionName in columnDefinitions){
                if (!this._isColumnEditable(definitionName, editableColumns)){
                    continue;
                }
                var column = columnDefinitions[definitionName];
                if (definitionName === "validDate"){
                    column.formatter = lang.hitch(this, this._validDateFormatter);
                } else if(definitionName === "unitPrice"){
                    column.formatter = lang.hitch(this, this._unitPriceFormatter);
                } else if (definitionName === "priceCode"){
                    column.formatter = lang.hitch(this, this._priceCodeFormatter);
                } else if(column.editorArgs && column.editorArgs.selections && column.editorArgs.selections.length > 0){
                    column.formatter = this._getSelectionFormatter(column);
                } else{
                    column.formatter = this._editableValueFormatter;
                }
                column.className = column.className ? column.className + " epi-dgrid--editable" : "epi-dgrid--editable";
            }
        },

        _isColumnEditable: function(columnName, editableColumns){
            return array.some(editableColumns, function(editableColumn){
                return epiString.pascalToCamel(editableColumn) === columnName;
            });
        },

        _validDateFormatter: function(value){
            var formattedDate = this._formatValidDate(value);
            return this._editableValueFormatter(formattedDate);
        },

        _editableValueFormatter: function(value){
            return '<span class="epi-dgrid--editable__content">' + value + '</span>';
        },

        _formatValidDate: function (value) {
            // Format datetime
            return this._formatDate(value.validFrom) + " - " + this._formatDate(value.validUntil);
        },

        _formatDate: function (datetime) {
            // summary:
            //      Format datetime to short type.
            // datetime: Object
            //      The raw data.
            // tags:
            //      public

            return datetime && datetime !== "" ? epiDate.toUserFriendlyString(datetime) : res.untildatenotdefined;
        },

        _unitPriceFormatter: function(value){
            var formattedCurrency = currency.format(value.amount, { currency: value.currency });
            return this._editableValueFormatter(formattedCurrency);
        },

        _priceCodeFormatter: function(value){
            var encodedValue = htmlEntities.encode(value);
            return this._editableValueFormatter(encodedValue);
        },

        _getSelectionFormatter: function(column){
            // summary:
            //      On widgets with selections we need to display the text of the selection instead of the value.

            return lang.hitch(this, function(value){
                var html = "";
                array.some(column.editorArgs.selections, function(selection) {
                    if (selection.value === value) {
                        value = selection.text;
                        return true;
                    }
                });
                return this._editableValueFormatter(value);
            });
        }
    });
});