﻿define("epi-ecf-ui/contentediting/editors/CategoryCollectionEditor", [
    // dojo
    "dojo/_base/declare",
    // EPi Framework
    "epi/shell/widget/_FocusableMixin",
    // ecf-ui
    "./_RelationCollectionEditorBase",
    "../viewmodel/CategoryCollectionEditorModel",
    "./LinkEditEditor",
    "../ModelSupport",
    // Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.categorycollectioneditor"
],
function (
    //dojo
    declare,
    // Epi Framework
    _FocusableMixin,
    // ecf-ui
    _RelationCollectionEditorBase,
    CategoryCollectionEditorModel,
    LinkEditEditor,
    ModelSupport,
    // Resources
    resources
) {
    var collectionEditor = declare([_RelationCollectionEditorBase, _FocusableMixin], {
        // module:
        //      epi-ecf-ui/contentediting/editors/RelationCollectionEditEditor
        // summary:
        //      Represents the Read-only editor widget for product's price overview list.

        modelType: CategoryCollectionEditorModel,

        allowedDndTypes: [ModelSupport.contentTypeIdentifier.nodeContent, ModelSupport.linkTypeIdentifier.relation],

        itemEditorTypes: [ModelSupport.contentTypeIdentifier.nodeContent],

        resources: resources,

        relationType: ModelSupport.relationType.node
    });

    return declare([LinkEditEditor], {

        resources: resources,

        gridCollectionType: collectionEditor
    });
});
